# -*- coding: utf-8 -*-
# This file is here to ensure that upgrades of salt remove the external_ip
# grain, this file should be removed in the Boron release
